=== The Day We Fight Back ===
Contributors: modemlooper
Tags: nsa, the day we fight back
Tested up to: 3.8
Version: 1.0
Stable Tag: 1.0


== Description ==
Description: Add a banner to your site in opposition to mass surveillance on 02/11 thedaywefightback.org

== install ==
Upload tdwfb.zip to your WordPress plugins folder and activate.

Visit Settings > TDWFB and choose options. The banner is meant to be displayed on the date of the event. Leave Display date unchecked and the banner will display at midnight on 2/11 and last for 24 hours. To test the banner check Display date option and visit the front of your site. 

Options:
- Custom Greeting text
- Display banner before date 2/11
- Display only call form

Demo:
http://tfrce.github.io/thedaywefightback.js/example/banner.html


Issues: 
If you activate plugin and banner isn't showing check the Disable date option. You may need to delete your cache if running a cache plugin. 
